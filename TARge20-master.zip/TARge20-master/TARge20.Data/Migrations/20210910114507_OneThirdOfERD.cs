﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace TARge20.Data.Migrations
{
    public partial class OneThirdOfERD : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Employee");

            migrationBuilder.CreateTable(
                name: "Regioons",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    Regioon_In = table.Column<string>(nullable: true),
                    Loomise_Kuupaev = table.Column<DateTime>(nullable: false),
                    Sulemise_kuupaev = table.Column<DateTime>(nullable: false),
                    Kommentaar = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Regioons", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Vaheladus",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Nimi = table.Column<string>(nullable: true),
                    Algus = table.Column<DateTime>(nullable: false),
                    Lopp = table.Column<DateTime>(nullable: false),
                    Kommentaar = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Vaheladus", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Valjaannes",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Kood = table.Column<string>(nullable: true),
                    Nimetus = table.Column<string>(nullable: true),
                    Ilmumise_Sagedus = table.Column<int>(nullable: false),
                    Kommentaar = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Valjaannes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Piirkonds",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    Loomise_Kuupaev = table.Column<DateTime>(nullable: false),
                    Sulemise_kuupaev = table.Column<DateTime>(nullable: false),
                    Kommentaar = table.Column<string>(nullable: true),
                    RegioonId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Piirkonds", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Piirkonds_Regioons_RegioonId",
                        column: x => x.RegioonId,
                        principalTable: "Regioons",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Valjaanne_Eksemplars",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Kaal = table.Column<int>(nullable: false),
                    Kommentaar = table.Column<string>(nullable: true),
                    ValjaanneId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Valjaanne_Eksemplars", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Valjaanne_Eksemplars_Valjaannes_ValjaanneId",
                        column: x => x.ValjaanneId,
                        principalTable: "Valjaannes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Postkasts",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Aadress = table.Column<string>(nullable: true),
                    Kommentaar = table.Column<string>(nullable: true),
                    PiirkondId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Postkasts", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Postkasts_Piirkonds_PiirkondId",
                        column: x => x.PiirkondId,
                        principalTable: "Piirkonds",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Töötaja_Piirkonds",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    alguskuupaev = table.Column<DateTime>(nullable: false),
                    loppkuupaev = table.Column<DateTime>(nullable: false),
                    Kommentaar = table.Column<string>(nullable: true),
                    PiirkondId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Töötaja_Piirkonds", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Töötaja_Piirkonds_Piirkonds_PiirkondId",
                        column: x => x.PiirkondId,
                        principalTable: "Piirkonds",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Komplekt_Akts",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Komplekti_Akti_number = table.Column<string>(nullable: true),
                    Kuupaev = table.Column<DateTime>(nullable: false),
                    Kommentaar = table.Column<string>(nullable: true),
                    Töötaja_PiirkondId = table.Column<Guid>(nullable: true),
                    VaheladuId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Komplekt_Akts", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Komplekt_Akts_Töötaja_Piirkonds_Töötaja_PiirkondId",
                        column: x => x.Töötaja_PiirkondId,
                        principalTable: "Töötaja_Piirkonds",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Komplekt_Akts_Vaheladus_VaheladuId",
                        column: x => x.VaheladuId,
                        principalTable: "Vaheladus",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Postkast_Komplektiss",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Kommentaar = table.Column<string>(nullable: true),
                    Komplekt_AktId = table.Column<Guid>(nullable: true),
                    PostkastId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Postkast_Komplektiss", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Postkast_Komplektiss_Komplekt_Akts_Komplekt_AktId",
                        column: x => x.Komplekt_AktId,
                        principalTable: "Komplekt_Akts",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Postkast_Komplektiss_Postkasts_PostkastId",
                        column: x => x.PostkastId,
                        principalTable: "Postkasts",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Valjaanne_Komplektiss",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Eksemplaride_arv = table.Column<int>(nullable: false),
                    Kommentaar = table.Column<string>(nullable: true),
                    Komplekt_AktId = table.Column<Guid>(nullable: true),
                    Valjaanne_EksemplarId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Valjaanne_Komplektiss", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Valjaanne_Komplektiss_Komplekt_Akts_Komplekt_AktId",
                        column: x => x.Komplekt_AktId,
                        principalTable: "Komplekt_Akts",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Valjaanne_Komplektiss_Valjaanne_Eksemplars_Valjaanne_EksemplarId",
                        column: x => x.Valjaanne_EksemplarId,
                        principalTable: "Valjaanne_Eksemplars",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Komplekt_Akts_Töötaja_PiirkondId",
                table: "Komplekt_Akts",
                column: "Töötaja_PiirkondId");

            migrationBuilder.CreateIndex(
                name: "IX_Komplekt_Akts_VaheladuId",
                table: "Komplekt_Akts",
                column: "VaheladuId");

            migrationBuilder.CreateIndex(
                name: "IX_Piirkonds_RegioonId",
                table: "Piirkonds",
                column: "RegioonId");

            migrationBuilder.CreateIndex(
                name: "IX_Postkast_Komplektiss_Komplekt_AktId",
                table: "Postkast_Komplektiss",
                column: "Komplekt_AktId");

            migrationBuilder.CreateIndex(
                name: "IX_Postkast_Komplektiss_PostkastId",
                table: "Postkast_Komplektiss",
                column: "PostkastId");

            migrationBuilder.CreateIndex(
                name: "IX_Postkasts_PiirkondId",
                table: "Postkasts",
                column: "PiirkondId");

            migrationBuilder.CreateIndex(
                name: "IX_Töötaja_Piirkonds_PiirkondId",
                table: "Töötaja_Piirkonds",
                column: "PiirkondId");

            migrationBuilder.CreateIndex(
                name: "IX_Valjaanne_Eksemplars_ValjaanneId",
                table: "Valjaanne_Eksemplars",
                column: "ValjaanneId");

            migrationBuilder.CreateIndex(
                name: "IX_Valjaanne_Komplektiss_Komplekt_AktId",
                table: "Valjaanne_Komplektiss",
                column: "Komplekt_AktId");

            migrationBuilder.CreateIndex(
                name: "IX_Valjaanne_Komplektiss_Valjaanne_EksemplarId",
                table: "Valjaanne_Komplektiss",
                column: "Valjaanne_EksemplarId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Postkast_Komplektiss");

            migrationBuilder.DropTable(
                name: "Valjaanne_Komplektiss");

            migrationBuilder.DropTable(
                name: "Postkasts");

            migrationBuilder.DropTable(
                name: "Komplekt_Akts");

            migrationBuilder.DropTable(
                name: "Valjaanne_Eksemplars");

            migrationBuilder.DropTable(
                name: "Töötaja_Piirkonds");

            migrationBuilder.DropTable(
                name: "Vaheladus");

            migrationBuilder.DropTable(
                name: "Valjaannes");

            migrationBuilder.DropTable(
                name: "Piirkonds");

            migrationBuilder.DropTable(
                name: "Regioons");

            migrationBuilder.CreateTable(
                name: "Employee",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employee", x => x.Id);
                });
        }
    }
}
