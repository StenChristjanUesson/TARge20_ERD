﻿// using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TARge20.Core.Domain;

namespace TARge20.Data
{
    public class TARge20DbContext : DbContext
    {

        public TARge20DbContext(DbContextOptions<TARge20DbContext> options)
            : base(options) { }
        
        // näide, kuidas teha, kui lisate domaini alla ühe objekti
        // migratsioonid peavad tulema siia libary-sse e TARge20.Data alla.
        public DbSet<Komplekt_Akt> Komplekt_Akts { get; set; }
        public DbSet<Piirkond> Piirkonds { get; set; }
        public DbSet<Postkast> Postkasts { get; set; }
        public DbSet<Postkast_Komplektis> Postkast_Komplektiss { get; set; }
        public DbSet<Regioon> Regioons { get; set; }
        public DbSet<Töötaja_Piirkond> Töötaja_Piirkonds { get; set; }
        public DbSet<Vaheladu> Vaheladus { get; set; }
        public DbSet<Valjaanne> Valjaannes { get; set; }
        public DbSet<Valjaanne_Eksemplar> Valjaanne_Eksemplars { get; set; }
        public DbSet<Valjaanne_Komplektis> Valjaanne_Komplektiss { get; set; }
    }
}