﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    class Tootaja
    {
        public Guid Id { get; set; }
        public string eesnimi { get; set; }
        public string perekonnanimi { get; set; }
        public string isikukood { get; set; }
        public string kontaktaadress { get; set; }
        public string kontakttelefon { get; set; }
        public string kontakt_e_mail { get; set; }
        public DateTime tool_alates { get; set; }
        public DateTime tool_kuni { get; set; }
        public string kandevoime { get; set; }
        public string Kommentaar { get; set; }
        public ICollection<Töötaja_Piirkond> Töötaja_Piirkonds { get; set; }
        public ICollection<Komplekt_Akt> Komplekt_Akts { get; set; }
    }
}
