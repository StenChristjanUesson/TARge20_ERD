﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Valjaanne_Komplektis
    {
        public Guid Id { get; set; }
        public int Eksemplaride_arv { get; set; }
        public string Kommentaar { get; set; }
    }
}
