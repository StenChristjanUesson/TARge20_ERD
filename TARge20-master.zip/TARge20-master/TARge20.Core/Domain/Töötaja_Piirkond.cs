﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Töötaja_Piirkond
    {
        public Guid Id { get; set; }
        public DateTime alguskuupaev { get; set; }
        public DateTime loppkuupaev { get; set; }
        public string Kommentaar { get; set; }
        public ICollection<Komplekt_Akt> Komplekt_Akts { get; set; }
    }
}
