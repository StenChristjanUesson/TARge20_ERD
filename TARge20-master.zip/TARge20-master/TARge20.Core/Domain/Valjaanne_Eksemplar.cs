﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Valjaanne_Eksemplar
    {
        public Guid Id { get; set; }
        public int Kaal { get; set; }
        public string Kommentaar { get; set; }
        public ICollection<Valjaanne_Komplektis> Valjaanne_Komplektiss { get; set; }
}
}
