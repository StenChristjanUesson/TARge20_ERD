﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Vaheladu
    {
        public Guid Id { get; set; }
        public string Nimi { get; set; }
        public DateTime Algus { get; set; }
        public DateTime Lopp { get; set; }
        public string Kommentaar { get; set; }
        public ICollection<Komplekt_Akt> komplekt_Akts { get; set; }
    }
}
