﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Valjaanne
    {
        public Guid Id { get; set; }
        public string Kood { get; set; }
        public string Nimetus { get; set; }
        public int Ilmumise_Sagedus { get; set; }
        public string Kommentaar { get; set; }
        public ICollection<Valjaanne_Eksemplar> Valjaanne_Eksemplars { get; set; }
    }
}
