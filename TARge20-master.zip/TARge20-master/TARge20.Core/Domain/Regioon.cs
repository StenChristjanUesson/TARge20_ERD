﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Regioon
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Regioon_In { get; set; }
        public DateTime Loomise_Kuupaev { get; set; }
        public DateTime Sulemise_kuupaev { get; set; }
        public string Kommentaar { get; set; }
        public ICollection<Piirkond> Piirkonds { get; set; }
    }
}
