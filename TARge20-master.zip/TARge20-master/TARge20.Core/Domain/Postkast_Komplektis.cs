﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Postkast_Komplektis
    {
        public Guid Id { get; set; }
        public string Kommentaar { get; set; }
    }
}
