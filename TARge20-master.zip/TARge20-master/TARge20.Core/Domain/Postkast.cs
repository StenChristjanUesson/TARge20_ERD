﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Postkast
    {
        public Guid Id { get; set; }
        public string Aadress { get; set; }
        public string Kommentaar { get; set; }
        public ICollection<Postkast_Komplektis> Postkast_Komplektiss { get; set; }
    }
}
