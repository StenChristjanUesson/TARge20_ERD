﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Piirkond
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public DateTime Loomise_Kuupaev { get; set; }
        public DateTime Sulemise_kuupaev { get; set; }
        public string Kommentaar { get; set; }
        public ICollection<Töötaja_Piirkond> Töötaja_Piirkonds { get; set; }
        public ICollection<Postkast> Postkasts { get; set; }
    }
}
