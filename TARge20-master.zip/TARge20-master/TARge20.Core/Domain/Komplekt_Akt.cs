﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Komplekt_Akt
    {
        public Guid Id { get; set; }
        public string Komplekti_Akti_number { get; set; }
        public DateTime Kuupaev { get; set; }
        public string Kommentaar { get; set; }
        public ICollection<Postkast_Komplektis> Postkast_Komplektiss { get; set; }
        public ICollection<Valjaanne_Komplektis> Valjaanne_Komplektiss { get; set; }
    }
}
